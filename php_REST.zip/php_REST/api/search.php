<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../class/utilisateurs.php';

$database = new Database();
$db = $database->getConnection();
  

$utilisateur = new Utilisateur($db);

$keywords=isset($_GET["s"]) ? $_GET["s"] : "";

$stmt = $utilisateur->search($keywords);
$num = $stmt->rowCount();

if($num>0){
  
    $utilisateurs_arr=array();
    $utilisateurs_arr["records"]=array();

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){

        extract($row);
  
        $utilisateur_item=array(
            "nom" => $nom,
            "prenom" =>$prenom,
            "email" => $email,
            "date_creation" => $date_creation
        );
  
        array_push($utilisateurs_arr["records"], $utilisateur_item);
    }
  

    http_response_code(200);
  
    echo json_encode($utilisateurs_arr);
}
  
else{
    http_response_code(404);
  
    echo json_encode(
        array("message" => "No utilisateurs found.")
    );
}
?>