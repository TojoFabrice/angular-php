<?php
    class Utilisateur{

        // Connection
        private $conn;

        // Table
        private $db_table = "utilisateur";

        // Columns
        public $id;
        public $nom;
        public $prenom;
        public $email;
        public $date_creation;

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getUtilisateurs(){
            $sqlQuery = "SELECT id, nom, prenom, email, date_creation FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // CREATE
        public function createUtilisateur(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                        SET
                            nom = :nom, 
                            prenom = :prenom, 
                            email = :email, 
                            date_creation = :date_creation";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->nom=htmlspecialchars(strip_tags($this->nom));
            $this->prenom=htmlspecialchars(strip_tags($this->prenom));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->date_creation=htmlspecialchars(strip_tags($this->date_creation));

            $stmt->bindParam(":nom", $this->nom);
            $stmt->bindParam(":prenom", $this->prenom);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":date_creation", $this->date_creation);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // read single
        public function getSingleUtilisateur(){
            $sqlQuery = "SELECT
                        id, 
                        nom, 
                        prenom, 
                        email, 
                        date_creation
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       id = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->id);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->nom = $dataRow['nom'];
            $this->prenom = $dataRow['prenom'];
            $this->email = $dataRow['email'];
            $this->date_creation = $dataRow['date_creation'];
        }        

        // UPDATE
        public function updateUtilisateur(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        nom = :nom, 
                        prenom = :prenom, 
                        email = :email, 
                        date_creation = :date_creation
                    WHERE 
                        id = :id";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->nom=htmlspecialchars(strip_tags($this->nom));
            $this->prenom=htmlspecialchars(strip_tags($this->prenom));
            $this->email=htmlspecialchars(strip_tags($this->email));
            $this->date_creation=htmlspecialchars(strip_tags($this->date_creation));
            $this->id=htmlspecialchars(strip_tags($this->id));
          

            $stmt->bindParam(":nom", $this->nom);
            $stmt->bindParam(":prenom", $this->prenom);
            $stmt->bindParam(":email", $this->email);
            $stmt->bindParam(":date_creation", $this->date_creation);
            $stmt->bindParam(":id", $this->id);

            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deleteUtilisateur(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }


        // search utilisateur
        function search($keywords){

            $query = "SELECT
                        nom, 
                        prenom, 
                        email, 
                        date_creation
                    FROM
                        ". $this->db_table ."
                    WHERE 
                        nom LIKE ?
                    ORDER BY
                        date_creation DESC";

            $stmt = $this->conn->prepare($query);
        
            $keywords=htmlspecialchars(strip_tags($keywords));
            $keywords = "%{$keywords}%";

            $stmt->bindParam(1, $keywords);
        
            $stmt->execute();
        
            return $stmt;
        }

    }
