export class Utilisateur{
    id: number;
    nom: string;
    prenom: string;
    email: string;
    date_creation: Date
}