import { Injectable } from '@angular/core';
import { Utilisateur } from '../Model/utilisateur';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from "rxjs/operators";

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  PHP_API_SERVER = "http://localhost:8080/api";

  constructor(private httpClient: HttpClient) { }

  getUser(): Observable<Utilisateur[]>{
    return this.httpClient.get<Utilisateur[]>(`${this.PHP_API_SERVER}/read.php`).pipe(
      map((res: any) =>{
        return res;
      })
    );
  }

  getUserById(id: number): Observable<Utilisateur>{
    return this.httpClient.get<Utilisateur>(`${this.PHP_API_SERVER}/single_read.php/?id=${id}`);
  }

  createUser(utilisateur: Utilisateur):Observable<Utilisateur>{
    return this.httpClient.post<Utilisateur>(`${this.PHP_API_SERVER}/create.php`, utilisateur);
  }

  updateUser(utilisateur: Utilisateur){
    // return this.httpClient.put<Utilisateur>(`${this.PHP_API_SERVER}/update.php/?id=${utilisateur.id}`, utilisateur)
    return this.httpClient.put<Utilisateur>(`${this.PHP_API_SERVER}/update.php`, utilisateur)
  }

  deleteUser(id: number){
    return this.httpClient.delete<Utilisateur>(`${this.PHP_API_SERVER}/delete.php/?id=${id}`)
  }
}
