import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Utilisateur } from 'src/app/Model/utilisateur';
import { ApiService } from 'src/app/service/api.service';
import { MdbTablePaginationComponent, MdbTableDirective } from 'angular-bootstrap-md';

@Component({
  selector: 'app-gestion-user',
  templateUrl: './gestion-user.component.html',
  styleUrls: ['./gestion-user.component.scss']
})
export class GestionUserComponent implements OnInit, AfterViewInit {
  @ViewChild(MdbTableDirective, { static: true }) mdbTable: MdbTableDirective;
  @ViewChild(MdbTablePaginationComponent, { static: true }) mdbTablePagination: MdbTablePaginationComponent;
  @ViewChild('row', { static: true }) row: ElementRef;
  elements: any = [];
  previous: any = [];
  headElements = ['id', 'nom', 'prenom', 'email', 'Modifier', 'Supprimer'];
  searchText: string = '';
  maxVisibleItems: number = 8;
  data: any

  utilisateurs: Utilisateur[];
  formdata: FormGroup;
  submitted = false;

  _id:number;
  prenom:string = '';
  nom:string = '';
  email:string = '';
  constructor(private apiService: ApiService, private cdRef: ChangeDetectorRef, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this. getAllUser();
  }

  getAllUser(){
    this.formdata = this.formBuilder.group({
      'id':[null],
      'nom': ['', Validators.required],
      'prenom': ['', Validators.required],
      'email': ['', [Validators.required, Validators.email]],
    });

    this.apiService.getUser().subscribe((res) => {
      console.log(res);
      this.elements = res;
      this.mdbTable.setDataSource(this.elements);
      this.elements = this.mdbTable.getDataSource();
      this.previous = this.mdbTable.getDataSource();
    })
  }

  ngAfterViewInit() {
    this.mdbTablePagination.setMaxVisibleItemsNumberTo(5);

    this.mdbTablePagination.calculateFirstItemIndex();
    this.mdbTablePagination.calculateLastItemIndex();
    this.cdRef.detectChanges();
  }

  searchItems() {
    const prev = this.mdbTable.getDataSource();

    if (!this.searchText) {
      this.mdbTable.setDataSource(this.previous);
      this.elements = this.mdbTable.getDataSource();
    }

    if (this.searchText) {
      this.elements = this.mdbTable.searchLocalDataBy(this.searchText);
      this.mdbTable.setDataSource(prev);
    }

    this.mdbTablePagination.calculateFirstItemIndex();
    this.mdbTablePagination.calculateLastItemIndex();

    this.mdbTable.searchDataObservable(this.searchText).subscribe(() => {
      this.mdbTablePagination.calculateFirstItemIndex();
      this.mdbTablePagination.calculateLastItemIndex();
    });
  }

  ajoutUtilisteur() {

    this.submitted = true;

    if (this.formdata.invalid) {
      return;
    }
    let id = this.formdata.controls['id'].value;
    if(id){
      this. updateUser();
    }else{
      console.log(this.formdata.value);
      this.apiService.createUser(this.formdata.value).subscribe();  
    }
    this.getAllUser();
    alert('SUCCESS!! :-)');
   

  }

  getUserById(id:number){
    this.apiService.getUserById(id).subscribe((data:Utilisateur) => {
      console.log(data);
      
      this.formdata.setValue({
        id: data.id || null,
        nom: data.nom,
        prenom: data.prenom,
        email: data.email
      })
    })
  }

  updateUser(){
    this.apiService.updateUser(this.formdata.value).subscribe();
  }

  deleteUser(id:number){
    this.apiService.deleteUser(id).subscribe();
    this.getAllUser();
  }
}

